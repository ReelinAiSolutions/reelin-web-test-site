import React, { useState } from 'react';
import { ContactFormData } from '../types';

export const Book: React.FC = () => {
  const [formData, setFormData] = useState<ContactFormData>({
    name: '',
    businessName: '',
    email: '',
    phone: '',
    message: ''
  });
  
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Lead Submitted:", formData);
    setSubmitted(true);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  return (
    <div className="min-h-screen pt-32 pb-20 px-4 sm:px-6 bg-background relative">
      <div className="absolute top-0 right-0 w-1/2 h-1/2 bg-primary/10 blur-[120px] rounded-full pointer-events-none" />
      
      <div className="max-w-5xl mx-auto grid lg:grid-cols-2 gap-16 relative z-10">
        <div>
          <h1 className="text-4xl md:text-5xl font-display font-bold text-white mb-6">
            Consult with an <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">Expert.</span>
          </h1>
          <p className="text-slate-400 text-lg mb-8 leading-relaxed">
            Map out your custom automation plan. Book a 15-minute review to see how AI can work with your current tools.
          </p>
          
          <div className="space-y-6">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center border border-white/10 shrink-0">
                <span className="text-primary font-bold">1</span>
              </div>
              <div>
                <h4 className="text-white font-medium">Business Review</h4>
                <p className="text-sm text-slate-500">We review your current tools and manual tasks.</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center border border-white/10 shrink-0">
                 <span className="text-primary font-bold">2</span>
              </div>
              <div>
                <h4 className="text-white font-medium">The Plan</h4>
                <p className="text-sm text-slate-500">We create a custom roadmap for your system.</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center border border-white/10 shrink-0">
                 <span className="text-primary font-bold">3</span>
              </div>
              <div>
                <h4 className="text-white font-medium">The Build</h4>
                <p className="text-sm text-slate-500">Receive a clear timeline for implementation.</p>
              </div>
            </div>
          </div>
        </div>

        <div className="glass-card p-8 rounded-2xl border border-white/10 shadow-2xl">
          {submitted ? (
            <div className="h-full flex flex-col items-center justify-center text-center py-20">
              <div className="w-16 h-16 bg-green-500/10 rounded-full flex items-center justify-center mb-6 text-green-500">
                <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h3 className="text-2xl font-bold text-white mb-2">Request Received</h3>
              <p className="text-slate-400">Our team will review your details and confirm your consultation slot shortly.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <h3 className="text-xl font-semibold text-white mb-6">Tell us about your business</h3>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs text-slate-400 font-medium ml-1">Name</label>
                  <input 
                    required 
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    className="w-full bg-slate-950/50 border border-white/10 rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-primary/50 focus:border-primary/50 focus:outline-none transition-all"
                    placeholder="Jane Doe"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs text-slate-400 font-medium ml-1">Business Name</label>
                  <input 
                    required 
                    name="businessName"
                    value={formData.businessName}
                    onChange={handleChange}
                    className="w-full bg-slate-950/50 border border-white/10 rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-primary/50 focus:border-primary/50 focus:outline-none transition-all"
                    placeholder="Acme Inc."
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs text-slate-400 font-medium ml-1">Work Email</label>
                <input 
                  required 
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full bg-slate-950/50 border border-white/10 rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-primary/50 focus:border-primary/50 focus:outline-none transition-all"
                  placeholder="jane@company.com"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs text-slate-400 font-medium ml-1">Phone Number</label>
                <input 
                  required 
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  className="w-full bg-slate-950/50 border border-white/10 rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-primary/50 focus:border-primary/50 focus:outline-none transition-all"
                  placeholder="(555) 123-4567"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs text-slate-400 font-medium ml-1">Current Tools / Challenges</label>
                <textarea 
                  required 
                  rows={4}
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  className="w-full bg-slate-950/50 border border-white/10 rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-primary/50 focus:border-primary/50 focus:outline-none transition-all resize-none"
                  placeholder="e.g. Using Salesforce but data entry is manual. Need to automate scheduling..."
                />
              </div>

              <button 
                type="submit"
                className="w-full py-4 bg-primary text-white font-bold rounded-lg hover:bg-primary/90 transition-colors shadow-lg shadow-primary/20 mt-4"
              >
                Request Consultation
              </button>
              
              <p className="text-xs text-center text-slate-500 mt-4">
                We sign NDAs for all enterprise consultations.
              </p>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};